import React from 'react';
import styles from '../theme/Header.module.css'; // Import CSS module
import Logo from '../assets/logo.png'; // Adjust the path to your logo

const Header: React.FC = () => {
  return (
    <header className={styles.headerContainer}>
      <div className={styles.logoContainer}>
        <img src={Logo} alt="Logo" className={styles.logo} />
      </div>
    </header>
  );
};

export default Header;
