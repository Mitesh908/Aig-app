// src/components/HomeHeader.tsx
import React from 'react';
import cartLogo from '../assets/icons/cart.svg';
import AIGLogo from '../assets/images/AIGLogo.png';
import '../theme/homeHeader.scss';

const HomeHeader: React.FC = () => (
    <header className="header-container">
        <div className='logoSection'>
            <h1 className="logo">
                <img src={AIGLogo} alt="AIG Logo" />
            </h1>
            <div className='cart'>
                <img src={cartLogo} alt="Cart Logo" />
            </div>
        </div>
        <div className="search-bar">
            <input className="search-input" placeholder="symptoms, diseases..." />
            <button className="search-button">Search</button>
        </div>
    </header>
);

export default HomeHeader;
