import React, { useState } from 'react';
import blog from '../assets/icons/blog.svg';
import blogLight from '../assets/icons/blogLight.svg';
import calenderLight from '../assets/icons/calenderLight.svg';
import home from '../assets/icons/home.svg';
import homeLight from '../assets/icons/homeLight.svg';
import notification from '../assets/icons/notification.svg';
import calender from '../assets/icons/today.svg';
import user from '../assets/icons/user.svg';

import notificationLight from '../assets/icons/notificationLight.svg';
import userLight from '../assets/icons/userLight.svg';
import '../theme/BottomNav.scss';

export const Bottom: React.FC = () => {
  const [active, setActive] = useState<number>(0); // Specify the type for state

  return (
    <div className="bottom-nav">
      <div className={`nav-item ${active === 0 ? 'active' : ''}`} onClick={() => setActive(0)}>
        <i className="icon">
          <img src={active === 0 ? blogLight : blog} alt="Blog" />
        </i>
      </div>
      <div className={`nav-item ${active === 1 ? 'active' : ''}`} onClick={() => setActive(1)}>
        <i className="icon">
          <img src={active === 1 ? calenderLight : calender} alt="Calendar" />
        </i>
      </div>
      <div className={`nav-item ${active === 2 ? 'active' : ''}`} onClick={() => setActive(2)}>
        <i className="icon">
          <img src={active === 2 ? homeLight : home} alt="Home" />
        </i>
      </div>
      <div className={`nav-item ${active === 3 ? 'active' : ''}`} onClick={() => setActive(3)}>
        <i className="icon">
          <img src={active === 3 ? notificationLight : notification} alt="Notification" />
        </i>
      </div>
      <div className={`nav-item ${active === 4 ? 'active' : ''}`} onClick={() => setActive(4)}>
        <i className="icon">
          <img src={active === 4 ? userLight : user} alt="User" />
        </i>
      </div>
    </div>
  );
};

export default Bottom;  
