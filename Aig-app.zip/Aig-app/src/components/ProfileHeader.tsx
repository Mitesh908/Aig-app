import React from 'react';
import styles from '../theme/Header.module.css'

const ProfileHeader: React.FC = () => {
  return (
    <header className={styles.headerContainer}>
      <p className={styles.profileText}>Profile</p>
    </header>
  );
};

export default ProfileHeader;
