import React, { useEffect, useState } from 'react';
import { Bottom } from '../components/Bottom';
import AIGLogo from '../assets/images/Logo.png'; // Corrected asset path
import doctorImg from "../assets/images/doctor.png"; // Corrected asset path

import Appointment from "../assets/icons/Appointment.svg";
import HealthHistory from "../assets/icons/HealthHistory.svg";
import HealthTest from "../assets/icons/HealthTest.svg";
import homeCare from "../assets/icons/homeCare.svg";
import parcel from "../assets/icons/parcel.svg";
import vitals from "../assets/icons/vitals.svg";
import '../pages/Home.scss';
import Header from '../components/homeHeader';

interface ServiceItem {
  id: number;
  title: string;
  content: string;
}

const HomePage: React.FC = () => {
  const [activeIndex, setActiveIndex] = useState<number>(0);
  const items: ServiceItem[] = [
    { id: 1, title: 'Consult with your doctor', content: 'Start consultation now' },
    { id: 2, title: 'Card 2', content: 'Content for Card 2' },
    { id: 3, title: 'Card 3', content: 'Content for Card 3' },
  ];

  // Automatically move to the next item every 3 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      setActiveIndex((prevIndex) => (prevIndex + 1) % items.length);
    }, 3000);

    return () => clearInterval(interval); // Clear the interval on unmount
  }, [items.length]);

  return (
    <>
      <Header />
      <div className='container'>
        <h2 style={{ marginLeft: '20px', fontSize: '18px' }}>Our Services</h2>
        <div className="services-grid">
          <div className="service-card random-color1">
            <div className="icon-background"></div>
            <h3>Book Appointment</h3>
            <i className="icon"><img src={Appointment} alt="Appointment Icon" /></i>
          </div>
          <div className="service-card random-color2">
            <div className="icon-background"></div>
            <h3>Health Package</h3>
            <i className="icon"><img src={parcel} alt="Health Package Icon" /></i>
          </div>
          <div className="service-card random-color3">
            <div className="icon-background"></div>
            <h3>Health Tests</h3>
            <i className="icon"><img src={HealthTest} alt="Health Test Icon" /></i>
          </div>
          <div className="service-card random-color4">
            <div className="icon-background"></div>
            <h3>Home Care</h3>
            <i className="icon"><img src={homeCare} alt="Home Care Icon" /></i>
          </div>
          <div className="service-card random-color4">
            <div className="icon-background"></div>
            <h3>My Health History</h3>
            <i className="icon"><img src={HealthHistory} alt="Health History Icon" /></i>
          </div>
          <div className="service-card random-color6">
            <div className="icon-background"></div>
            <h3>My Vitals</h3>
            <i className="icon"><img src={vitals} alt="Vitals Icon" /></i>
          </div>
        </div>

        <div className="carousel">
          <div className="carousel-content" style={{ transform: `translateX(-${activeIndex * 100}%)` }}>
            {items.map((item) => (
              <div key={item.id} className={`carousel-card ${item.id === items[activeIndex].id ? 'active' : ''}`}>
                <h2>{item.title}</h2>
                <p>{item.content}</p>
              </div>
            ))}
          </div>
        </div>

        <div className="single-card">
          <img src={AIGLogo} alt="AIG" className="card-image" />
          <h2 className="card-title">Symptoms Checker</h2>
        </div>
        <div>
          <h3>Top Consulted Doctors</h3>
          <div className="doctor-card">
            <img src={doctorImg} alt="Doctor" />
            <div className="doctor-info">
              <h4>Dr. Rupjyoti Talukdar</h4>
              <p>Director - Medical Gastroenterology</p>
              <p>10 years • 4.9 ⭐</p>
            </div>
            <button className='button'>Book</button>
          </div>
        </div>
      </div>
      <Bottom />
    </>
  );
};

export default HomePage;
